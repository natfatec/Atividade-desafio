import conn from './properties.js'

class Crud {

  /*static teste(){
    return "ok"
  }*/

  //Pega todos os registros
  getAllCars(cod, callback){
    let sql = "select * from carro where id = ?"
    conn.query(sql, cod, function(error,results,fields){
        if(error) throw error
        callback(results)
    })
        console.log(query.sql)
        conn.end()
  }

  //pega por Ids
  getById(id, callback){
    let sql = "select * from carro where id = ?"
    conn.query(sql, id, function(error, results, fields){
      if(error) throw error
      callback(results)
    })
      //console.log(query.sql)
      conn.end()
  }

  //Pega pelo nome
  getByName(nomeCarro, callback){
    let sql = "select * from carro where nomecarro = ?"
    conn.query(sql, nomeCarro, function(error, results, fields){
      if(error) throw error
      callback(results)
    })
      console.log(query.sql)
      conn.end()
  }

  //salvar
  save(carro, callback){
    let sql = "insert into carro set ?"
    conn.query(sql, carro, function(error,results,fields){
        if(error) throw error

        carro.id = results.insertId
        callback(carro)
    })
   // console.log(query.sql)
    conn.end()
  }

  //Atualiza campos
  update(id, carro, callback){
    let sql = "update carro set ? where id = ?"
    //let id = carro.id
    conn.query(sql, [carro,id], function(error,results,fields){
      if(error) throw error
      callback(results)
    })  
    //console.log(query.sql)
    conn.end()
  }

  //Apagar
  delete(id, callback){
    let sql = "delete from carro where id = ?"
    conn.query(sql, id, function(error,results,fields){
      if(error) throw error
      callback(results)
    })  
   // console.log(query.sql)
    conn.end()
  }
}

export default Crud 

//module.exports = Crud