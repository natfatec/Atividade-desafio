import Crud from './Crud.js';

const crud = new Crud();

function gravar() {
const carro = {"nomecarro":"impala 67","cor":"preto"}        
        crud.save(carro, function(carro){
           // res.json(carro)
        })
}

//gravar()

function atualizar(){
    const carro = {"id":17,"nomecarro":"bmw x6","cor":"prata"}  
    crud.update(carro.id,carro, function(carro){

    })

}

atualizar()

//gravar()

















